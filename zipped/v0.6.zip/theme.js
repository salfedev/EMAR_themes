console.info('JS is enabled. Jazz theme V.0.6');

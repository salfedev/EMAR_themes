console.info('Example message from example-css-image-theme.');

console.log("JS is enabled. Jazz theme V.0.1");

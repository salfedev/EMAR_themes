console.info('JS is enabled. RECCO theme V.1.5');

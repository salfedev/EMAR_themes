dojo.provide("jazz.theme.FooterLeftWidget");

/*
 * Imports 
 */

dojo.require("dijit._Widget");
dojo.require("dijit._Templated");

dojo.require("jazz.util.theming");

(function() {

/*
 * Aliases 
 */

/*
 * Class
 */
dojo.declare("jazz.theme.FooterLeftWidget",
	[dijit._Widget, dijit._Templated], {

	// Properties //----------------------------------------------------------->
	
	// ------------------------------------------------------------------------>
	
	/*
	 * Templates
	 */	
	templatePath: jazz.util.theming.themeFileUrl("templates/ThemeWidget.html"),
	
	/*
 	 * @param Object args
 	 * 
 	 * @return FooterLeftWidget
 	 */
	constructor: function(args) {
	   this._label = "Footer Left Widget";
	},
	
	/*
 	 * @param void
 	 * 
 	 * @return void
 	 * @overrides super
 	 */	
	postCreate: function() {

		this.inherited(arguments);

		// Instance Variables //----------------------------------------------->

		// Initialization //--------------------------------------------------->

		this._initButton();

	},

	/*
 	 * @param void
 	 * 
 	 * @return void
 	 */		
	_initButton: function() {
      var buttonElement = document.createElement("button");
      buttonElement.type = "button";
      buttonElement.innerHTML = "Button";
      this._buttonSite.appendChild(buttonElement);
	}

});

})();
